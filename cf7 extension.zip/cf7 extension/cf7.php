<?php
/**
* Plugin Name:       Contact Form 7 Extension
* Plugin URI:        https://meliodus.org/
* Description:       Adds additional Functionality to Contact Form 7
* Version:           1
* Requires at least: 5.2
* Requires PHP:      7
* Author:            Meliodus
* Author URI:        https://meliodus.org/
* License:           GPL v2 or later
* License URI:       https://www.gnu.org/licenses/gpl-2.0.html
* Text Domain:       meliodus
*/

if( !defined( 'ABSPATH' ) ) exit;

add_action( 'plugins_loaded', 'contact_form_plugin_check' );

function contact_form_plugin_check(){
    if(!class_exists('WPCF7_ContactForm')){
        add_action( 'admin_notices', 'meliodus_plugin_admin_notice' );
    } 
}

function meliodus_plugin_admin_notice() {
   echo '<div class="error"><p>'.'Meliodus Alert!!  This Plugin Requires Contact Form 7 Activated'.'</p></div>';
}

////////////////////////////////////////////////////////////////////////////////

/* Main Class for Contact Form7 Rich Text Editor Field */
if( !class_exists( 'Contact_Form7_Rich_Text' ) ) {
    
    class Contact_Form7_Rich_Text{
    
        private static $instance;

        /* Create instances of plugin classes and initializing the features  */
        public static function instance() {
            
            if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Contact_Form7_Rich_Text ) ) {
                self::$instance = new Contact_Form7_Rich_Text();
                self::$instance->setup_constants();

                //add_action( 'plugins_loaded', array( self::$instance, 'load_textdomain' ) );
                self::$instance->includes();

                add_action('wp_enqueue_scripts',array(self::$instance,'load_scripts'),9);
                 
                self::$instance->template_loader    = new CF7RT_Template_Loader();
                self::$instance->private_content    = new CF7RT_Rich_Text_Editor();
            }
            return self::$instance;
        }

        /* Setup constants for the plugin */
        private function setup_constants() {
            
            // Plugin version
            if ( ! defined( 'CF7RT_VERSION' ) ) {
                define( 'CF7RT_VERSION', '1.0' );
            }

            // Plugin Folder Path
            if ( ! defined( 'CF7RT_PLUGIN_DIR' ) ) {
                define( 'CF7RT_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
            }

            // Plugin Folder URL
            if ( ! defined( 'CF7RT_PLUGIN_URL' ) ) {
                define( 'CF7RT_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
            }

            
        }

        /* Load scripts and styles for frontend */
        public function load_scripts(){
          
            wp_register_style('cf7rt-front-style', CF7RT_PLUGIN_URL . 'css/cf7rt-front.css');
            wp_enqueue_style('cf7rt-front-style');
         
        }
        
        /* Include class files */
        private function includes() {

            require_once CF7RT_PLUGIN_DIR . 'template-loader.php';
            require_once CF7RT_PLUGIN_DIR . 'text-editor.php';
            
            if ( is_admin() ) {}
        }
    
    }
}

/* Intialize Contact_Form7_Rich_Text  instance */
function Contact_Form7_Rich_Text() {
    global $cf7rt;    
	$cf7rt = Contact_Form7_Rich_Text::instance();
}

Contact_Form7_Rich_Text();